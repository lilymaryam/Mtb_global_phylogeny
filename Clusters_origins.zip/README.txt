This zip contains the cluster files obtained from the global phylogeny approaches with the country of origin of those samples with the information in the metadata. 
